<?php 
$filename = "MOCACORE.sql";
$cfg_dbuser = "moca";
$cfg_dbpwd = "moca";
$cfg_dbname = "MOCACORE";

header("Content-disposition:filename=".$filename);
header("Content-type:application/octetstream");
header("Pragma:no-cache");
header("Expires:0");
$tmpFile = (dirname(__FILE__))."/".$filename;
$cmd = "mysqldump -u$cfg_dbuser -p$cfg_dbpwd --default-character-set=utf8 $cfg_dbname > ".$tmpFile;
exec($cmd);
$file = fopen($tmpFile, "a+");
echo fread($file,filesize($tmpFile));
fclose($file);
exit;
?> 